const {Router} = require('express');
const router = Router();
const TodoListItems = require('../../models/TodoListItems');

//method get

router.get('/', async (req, res) => {
    try {
        const items = await TodoListItems.find();

        res.status(200).json(items)
    } catch (error) {
        res.status(500).json({message: error.message})
    }
})

//method post
router.post('/', async (req, res) => {
    try {

        const newTodoListItems = new TodoListItems(req.body)
        const savedTodoListItems = await newTodoListItems.save()
        if(!savedTodoListItems) {
            res.status(500).json({message: 'Internal server error'})
        }

        res.status(200).json(savedTodoListItems)

    } catch (error) {
        res.status(500).json({message: error.message})
    }

})

//method put
router.put('/:id', async (req, res) => {
    try {
        const updatedTodoListItems = await TodoListItems.findByIdAndUpdate(req.params.id, req.body, {new: true})
        if(!updatedTodoListItems) {
            res.status(404).json({message: 'Not found'})
        }
        res.status(200).json(updatedTodoListItems)

    } catch (error) {
        res.status(500).json({message: error.message})
    }
})

//method delete
router.delete('/:id', async (req, res) => {
    try {
        const deletedTodoListItems = await TodoListItems.findByIdAndDelete(req.params.id)
        if(!deletedTodoListItems) {
            res.status(404).json({message: 'Not found'})
        }
        res.status(200).json('Deleted successfully')

    } catch (error) {
        res.status(500).json({message: error.message})
    }

})



module.exports = router