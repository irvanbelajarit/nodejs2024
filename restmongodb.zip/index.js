const express = require('express');
const app = express();
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const morgan = require('morgan');
dotenv.config();

const port = process.env.PORT || 5000
mongoose.connect(process.env.MONGO_URL).then(
    () => console.log(`Database connected ${process.env.MONGO_URL}`),
    err => console.log(err)
)

app.use(morgan('dev'))
app.use(express.json())
app.use('/api/todolistitems', require('./routes/api/todolistitems'))




app.listen(port, () => console.log(`Listening on port ${port}`))